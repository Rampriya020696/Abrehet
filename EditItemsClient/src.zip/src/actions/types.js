export const FETCH_DATA = 'fetch_data';
export const ADD_DATA = 'add_data';
export const DELETE_DATA = 'delete_data';
export const ROW_CLICK = 'row_click';
export const CHANGE_DATA = 'change_data';